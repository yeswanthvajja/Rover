﻿namespace RoverService.Models
{
    public class PhotoDto
    {
        public ItemDto[]? photos { get; set; }

    }
}
