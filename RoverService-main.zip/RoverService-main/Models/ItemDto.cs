﻿namespace RoverService.Models
{
    public class ItemDto
    {
        public string? img_src { get; set; }
        public DateTime earth_date { get; set; }
    }
}
